class Search < ActiveRecord::Base

end
